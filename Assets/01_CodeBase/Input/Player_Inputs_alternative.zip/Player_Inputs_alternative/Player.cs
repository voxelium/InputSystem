
using UnityEngine;
using static UnityEngine.InputSystem.InputAction;

public class Player : MonoBehaviour
{
    public Player_Inputs Controls;

    public float MoveSpeed = 8f;
    public float TurnSpeed = 120f;
    public float JumpForce = 10f;
    private bool isGrounded;

    private Rigidbody _rigidbody;


    void Awake()
    {
        Controls = new Player_Inputs();
    }


    void OnEnable()
    {
        Controls.Movement.Enable();

        Controls.Movement.Jump.performed += Jump;
        Controls.Movement.Fire.performed += Fire;
    }


    void Start()
    {
        _rigidbody = GetComponent<Rigidbody>();

    }


    void Update()
    {
        Moving();
    }


    private void Moving()
    {
        Vector2 value = Controls.Movement.Move.ReadValue<Vector2>();
        transform.position += new Vector3(value.x, 0, value.y) * Time.deltaTime * MoveSpeed;
    }


    private void Jump(CallbackContext inputValue) // Values from PlayerInput component
    {
        if (isGrounded)
        {
            _rigidbody.AddRelativeForce(Vector3.up * JumpForce, ForceMode.VelocityChange);
        }
    }



    private void Fire(CallbackContext context)
    {
        Debug.LogWarning("FIRE");
    }


    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Ground"))
        {
            isGrounded = true;
        }
    }

    private void OnCollisionExit(Collision collision)
    {
        if (collision.gameObject.CompareTag("Ground"))
        {
            isGrounded = false;
        }
    }


    void OnDestroy()
    {
        Controls.Movement.Jump.performed -= Jump;
        Controls.Movement.Fire.performed -= Fire;
    }

}

